<section class="footer">

   <div class="box-container">


      <div class="box">
         <h3>contact info</h3>
         <p> <i class="fas fa-phone"></i> +880-181-***** </p>
         <p> <i class="fas fa-envelope"></i> blissfulEssentials@gmail.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> Dhaka, Bangladesh - 1206 </p>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
      </div>

   </div>

   <p class="credit"> &copy; BEYDL <?php echo date('Y'); ?> <span>All rights reserved</span> </p>
   

</section>
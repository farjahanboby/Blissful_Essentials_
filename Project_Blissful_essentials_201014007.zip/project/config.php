<?php

$conn = mysqli_connect('localhost','root','','shop_db') or die('connection failed');//server connected, username, password, database name

?>